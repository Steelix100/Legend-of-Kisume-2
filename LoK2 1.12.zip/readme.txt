The Legend of Kisume 2
Version 1.12

Controls:
Z - Action Button
X - Action Button
Shift - Show Hitbox
Enter/Return - Pause Menu
Esc - Quit
Shift + Esc - Soft Reset

Changelog:

Version 1.12
- Made the sword stronger
- Fixed a glitch causing the 6th boss to crash
- Added version number to the window title
Version 1.11

- Fixed a game-breaking glitch in the top-left corner area
Version 1.1
- First public release
- Toned down the difficulty of the 4th boss
- Made the sword stronger
- Gave some enemies slightly more HP
- Soft Reset now returns to the title screen
- Shrunk the filesize slightly
Version 1.0
- Game was made

Obligatorily Sarcastic Comments:
* Forgot Metroid in the "credits". Meh.
